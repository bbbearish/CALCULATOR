package learn;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import learn.CalculatMath.BiOperatorModes;
import learn.CalculatMath.MonoOperatorModes;

public class calculator_ui implements ActionListener{
	//private variable
	private final JFrame frame;
	private final JPanel panel;
	private final JTextArea text;
	//array of buttons
	private final JButton buttons[], plusButton, minusButton, multyButton, divButton,
	equalButton, CButton, sqarButButton, squarButton, divByOne,
	CosinusBUTTON, sinusButton, tangesButton;
	//array of numbers
	private final String[] NUMBERS = { "0", "1", "2", "3", "4", "5", "6",
			"7", "8", "9" };
	private final CalculatMath calculatorbb;

	//constructor
	public calculator_ui() {
		//set name to the calculator
		frame = new JFrame("BEARISH CALCULATOR");
		//Don't Change the size of the calculator 
		frame.setResizable(false);
		//change the size between the amount of buttons 
		panel = new JPanel(new FlowLayout());
		//set the place for the text window inside the frame
		text = new JTextArea(2, 30);
		//create array of 10 buttons and send them with cast from string to integer to the frame 
		buttons = new JButton[10];
		for (int i = 0; i < 10; i++) {
			buttons[i] = new JButton(String.valueOf(i));
		}
		//add the sign buttons 
		plusButton = new JButton("+");
		minusButton = new JButton("-");
		multyButton = new JButton("*");
		divButton = new JButton("/");
		equalButton = new JButton("=");
		sqarButButton = new JButton("√");
		squarButton = new JButton("x*x");
		divByOne = new JButton("1/x");
		CosinusBUTTON = new JButton("Cos");
		sinusButton = new JButton("Sin");
		tangesButton = new JButton("Tan");
		CButton = new JButton("C");
		calculatorbb = new CalculatMath();
	}

	public void init()  {
		//set frame properties
		frame.setVisible(true);
		frame.setSize(400, 170);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(panel);
		//add the text to the panel and add the buttons 
		panel.add(text);
		panel.add(CButton);
		for (int i = 0; i < 10; i++) {
			panel.add(buttons[i]);
			buttons[i].addActionListener(this);
		}
		//add the buttons to the panel
		panel.add(plusButton);
		panel.add(minusButton);
		panel.add(multyButton);
		panel.add(divButton);
		panel.add(squarButton);
		panel.add(sqarButButton);
		panel.add(divByOne);
		panel.add(CosinusBUTTON);
		panel.add(sinusButton);
		panel.add(tangesButton);
		panel.add(equalButton);

		//  action listener
		plusButton.addActionListener(this);
		minusButton.addActionListener(this);
		multyButton.addActionListener(this);
		divButton.addActionListener(this);
		squarButton.addActionListener(this);
		sqarButButton.addActionListener(this);
		divByOne.addActionListener(this);
		CosinusBUTTON.addActionListener(this);
		sinusButton.addActionListener(this);
		tangesButton.addActionListener(this);
		equalButton.addActionListener(this);
		CButton.addActionListener(this);
	}

	//all the math function that the button will do 
	@Override
	public void actionPerformed(ActionEvent e) {
		final Object source = e.getSource();

		for (int i = 0; i < 10; i++) {
			if (source == buttons[i]) {
				text.replaceSelection(NUMBERS[i]);
				return;
			}
		}

		if (source == plusButton) {
			number_writer(calculatorbb.calculateBi(CalculatMath.BiOperatorModes.add, number_reader()));
		}

		if (source == minusButton) {
			number_writer(calculatorbb.calculateBi(CalculatMath.BiOperatorModes.minus, number_reader()));
		}

		if (source == multyButton) {
			number_writer(calculatorbb.calculateBi(CalculatMath.BiOperatorModes.multy,
					number_reader()));
		}

		if (source == divButton) {
			number_writer(calculatorbb
					.calculateBi(CalculatMath.BiOperatorModes.div, number_reader()));
		}

		if (source == squarButton) {
			number_writer(calculatorbb.calculateMono(CalculatMath.MonoOperatorModes.square,
					number_reader()));
		}

		if (source == sqarButButton) {
			number_writer(calculatorbb.calculateMono(CalculatMath.MonoOperatorModes.squareRoot,
					number_reader()));
		}

		if (source == divByOne) {
			number_writer(calculatorbb.calculateMono(
					CalculatMath.MonoOperatorModes.oneDevidedBy, number_reader()));
		}

		if (source == CosinusBUTTON) {
			number_writer(calculatorbb.calculateMono(CalculatMath.MonoOperatorModes.cos,
					number_reader()));
		}

		if (source == sinusButton) {
			number_writer(calculatorbb.calculateMono(CalculatMath.MonoOperatorModes.sin,
					number_reader()));
		}

		if (source == tangesButton) {
			number_writer(calculatorbb.calculateMono(CalculatMath.MonoOperatorModes.tan,
					number_reader()));
		}
		if (source == equalButton) {
			number_writer(calculatorbb.calculateEqual(number_reader()));
		}

		if (source == CButton) {
			number_writer(calculatorbb.reset());
		}

		text.selectAll();
	}

	public double number_reader(){
		Double num1 ;
		String s ;
		s=text.getText();
		num1=Double.valueOf(s);

		return num1;			

	}
	
	public void number_writer(final Double num) {
		if (Double.isNaN(num)) {
			text.setText("");
		} else {
			text.setText(Double.toString(num));
		}
	}




	//print that  calculator !!!
	public static void main(String[] args) {
		calculator_ui nc = new calculator_ui();
		nc.init();
	}

}




